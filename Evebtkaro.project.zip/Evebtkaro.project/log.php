<?php
// Connect to your database here (make sure to replace the placeholders with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$database= "eventkaro";

$con =new MySQLi ($servername , $username, $password,$database);

// Check connection
//if ($mysqli->connect_error) {
  //  printf("Connection failed: " ,$mysqli->connect_error);
    //exit();

//}
//printf("connection sucses fully");
session_start();
    $username = $_POST['uname'];  
    $password = $_POST['password'];  
      
    $username = stripcslashes($username);  
            $password = stripcslashes($password);  
            $username = mysqli_real_escape_string($con, $username);  
            $password = mysqli_real_escape_string($con, $password);  
          
    
        $sql = "select *from sinup where uname = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
       $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
     $count = mysqli_num_rows($result);  
          
        if($count===1){  
            $_SESSION["login"]="1";
            echo "<script>window.location.href='index.php';
            alert(' you are logd in');</script>";
          
               }  
        else{  
            echo "<script>window.location.href='login.php';
            alert(' Login failed. Invalid username or pass');</script>";
           // header("location:login.php");
        }
     
       
       /* $username = $_POST['uname'];  
        $password = $_POST['password'];  
          
            //to prevent from mysqli injection  
            $username = stripcslashes($username);  
            $password = stripcslashes($password);  
            $username = mysqli_real_escape_string($con, $username);  
            $password = mysqli_real_escape_string($con, $password);  
          
            $sql = "select *from sinup where uname = '$username' and password = '$password'";  
            $result = mysqli_query($con, $sql);  
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
            $count = mysqli_num_rows($result);  
              
            if($count == 1){  
                echo "<script><script>window.location.href='price.php';
                alert('Login successful')";  
            }  
            else{  
                echo "<script><script>window.location.href='login.php';
                alert('<h1><center> Login not compllt username and and password does not exist  </center></h1>)'";  
            }    */ 
?>