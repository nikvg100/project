<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Login</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>

<!--singup-->
    <section class="contect">
        
        <form action="log.php" method="POST">
            
            <br/><br/>
            <h2 class="t-cont">Login</h2>
            <div class="form1">
           <a  href="index.php"><p style=" text-align:end ;;margin-block-end: 70px;">&#10006<p></a>
               
              <input type="text" name="uname" placeholder="Enter your username" required>
                <input type="password" name="password" placeholder="Enter Your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" >
                  
                <div style="text-align: center; ">
                    <button class="" type="submit" name="login" style="background-color: darkslategray; width: 80%;color: white; height: 30px; border: 1px solid ; border-radius: 9px; margin-top: 20px;">Login</button>
                </div>
              <a href="singup.php" style="text-decoration: none; color:darkslategrey"><h1 style="margin-top: 40px; ">You are not register then clike this </h1></a>
              <br/>
              <br/>
              <br/>
              <br/>
              <br/>
              <br/>

            </div>
        </form>
    </section>
    <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="resp.js"></script>

</body>

</html>