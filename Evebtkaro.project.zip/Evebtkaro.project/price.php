<?php 
session_start ();
if(!isset($_SESSION["login"]))
	header("location:login.php");


?>
<html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Login</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

</head>

    <body>
    <?php include 'nev.php' ?>


    <section class="section s-left">
        <div class="para">
            <p  class="sectag textbig ">Price</p>
            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070Type Of Packge With Price</h2>
<p  style=" color:darkslategray ; font-size:large"> We offer You So many type of Services You cane choose and contect us </p>
           
            <ul class="card-ul" style="display :flex;">

                <li>
                    <div class="card">
                        <img src="img\grand.jpg" alt="Avatar" style="width:250px ; height: 250px;">
                        <div class="container">
                            <h3><b>Grand Royal Wedding </b></h3>
                            <p style="font-family: cursive;">fully manage and all <br>functionality include inthis
                                <br /> Wedding
                            </p>
                            <hr/>
                            <p>&#8377 2100000 (21 lakh)</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book</a></button>
                        </div>
                </li>



                <li>
                    <div class="card">
                        <img src="img\pp.jpg" alt="Avatar" style="width:250px ; height: 250px;">
                        <div class="container">
                            <h3><b> persional partty</b></h3>
                            <p style="font-family: cursive;">Fully manage parrty eith <br/>all fasility  event</p>
                            <br/>
                            <hr/>
                            <p>&#8377 230000 (2.3 lakh)</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\manage.jpg" alt="Avatar" style="width:250px ; height: 250px;">
                        <div class="container">
                            <h3><b>Only mangment</b></h3>
                            <p style="font-family: cursive;"> only manage event <br/>dacoration not include <br />meeting</p>
                            
                            <hr/>
                            <p>&#8377 75000 (75 thousend)</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book </a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\party.jpg" alt="Avatar" style="width:250px ; height: 250px;">
                        <div class="container">
                            <h3><b>small Parrty</b></h3>
                            <p style="font-family: cursive;">like Birthday and <br />many more    </p>
                            <br/>
<hr/>
                            <p>&#8377 35000 (35 thousend)</p>

                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>


            </ul>
           
    </section>

        <button style=" background-color: darkslateblue; height: 30px; width: 120px; text-align: center;"><a style="text-decoration: none; color:white" href="logout.php">logout</a></button>
        <script src="resp.js"></script>
        
        <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>


    </body>
</html>