burger=document.querySelector('.burger')
nevbar=document.querySelector('.nevbar')

nevlist=document.querySelector('.nevlist')

burger.addEventListener('click',()=>{
   
    nevlist.classList.toggle('v-class-resp');
    nevbar.classList.toggle('h-nev-resp');
   

})
