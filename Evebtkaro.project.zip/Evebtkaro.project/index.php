<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> EventKaro</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
    <!-- <div  class="background hed"><h3 class="header"> &#128222  Mobile-No 9510042171</h3></div>-->

    <?php include 'nev.php' ?>


    <section class="background fse">

        <div class="box-main">
            <div class="firsthaf">
                <p class="textbig">Welcome In EventKaro.com</p>
                <p class="textsm">EventKaro is dedicated to creating memorable and seamless event experiences that leave a lasting impression. We believe in the power of exceptional event management to bring people together, inspire, and celebrate life's special moments.
                    </p>
                <div class="button">
                    <ul style="display: flex;">
                        <li style=" list-style: none; display: flex; "><button class="logbtn  btn "><a style="color: cadetblue;     text-decoration: none;
" href="login.php">Login</a></button></li>
                        <li style=" list-style: none; "><button class="logbtn btn"><a style="color: cadetblue;     text-decoration: none;
" href="singup.php">Singup</a></button></li>
                    </ul>


                </div>
            </div>

            <div class="secondhaf">
                <img src="img\loek.png" alt="eklogo">
            </div>
        </div>
    </section>
<!--about-->

    <section class="section ">
        <div class="para ">
        <!--<div class="thumbnel">
                <img src="img\loek.png" alt="Aboutnus" class="imgFluid">
</div>-->
        <p class="sectag textbig" style="padding-top: 50px;">About-Us</p>
       <br/>
            <br/>
            <br/>
            <br/>

            <p class=" secsubtag textsm" >
            
<table style="border: 2px solid darkgreen;  ;width :98%">
           <h2 style="color:darkslategrey">Company Name: EventKaro</h2>
    <br/>
        <h2>Established Since: 2005</h2>
        <br/>
        <h2>Mission:</h2>
        <p style="font-size: medium ;color:darkslategrey">EventKaro is dedicated to creating memorable and seamless event experiences that leave a lasting impression. We believe in the power of exceptional event management to bring people together, inspire, and celebrate life's special moments.</p>
        <br/>
        <h2>Our Story:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">Founded in 2005, EventKaro has been a pioneer in the event management industry, delivering outstanding services and unparalleled creativity for nearly two decades. Our journey began with a passion for turning ordinary events into extraordinary experiences. Over the years, we have grown and evolved, always staying at the forefront of industry trends and technologies.</p>
        <br/>
        <h2>What We Do:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">EventKaro specializes in comprehensive event management services tailored to the unique needs and visions of our clients. We offer a wide range of services, including:</p>
        <br/>
        <ol>
            <li >Corporate Events: From conferences and seminars to product launches and team-building activities, we help businesses create impactful events that drive success and engagement.</li>
            <li>Social Events: We excel in planning and executing social gatherings such as weddings, birthdays, anniversaries, and more, ensuring that each moment is cherished.</li>
            <li>Concerts and Entertainment: Our expertise extends to organizing concerts, live performances, and entertainment events that leave audiences thrilled.</li>
            <li>Exhibitions and Trade Shows: We help businesses showcase their products and services effectively through meticulously organized exhibitions and trade shows.</li>
            <li>Destination Management: EventKaro handles all aspects of destination events, ensuring seamless planning, logistics, and execution in the most picturesque locations.</li>
        </ol>
        <br/>
        <h2>Why Choose EventKaro:</h2>
        <br/>
        <ul>
            <li>Experience: With almost two decades of experience, EventKaro has a proven track record of delivering exceptional events.</li>
            <li>Creativity: Our team of talented professionals brings innovative and creative ideas to every project, ensuring a unique and memorable experience.</li>
            <li>Attention to Detail: We are known for our meticulous planning and execution, leaving no stone unturned to make your event flawless.</li>
            <li>Client-Centric Approach: We prioritize our clients' needs and preferences, working closely with them to bring their vision to life.</li>
            <li>Cutting-Edge Technology: We leverage the latest event management tools and technologies to enhance the event experience.</li>
        </ul>
        <br/>
        <h2>Contact Us:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">For inquiries and consultations, please reach out to us at:</p>
        <br/>
        <address>
            EventKaro<br>
            [Jetpur Junaght rod  street no 9 near patrolpump]<br>
            [951000000]<br>
            [eventkaro2005@gmail.com]<br>
            
        </address>
        
        <p style="font-size: medium ;color:darkslategrey">At EventKaro, we believe that every event is an opportunity to create magic. Let us be your partner in crafting unforgettable moments that will be cherished for a lifetime.</p>
</table>


        
    </section>

    <!-- services-->
    <hr />

    <section class="section s-left">
        <div class="para">
            <p  class="sectag textbig ">services</p>
            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070Type Of Event</h2>
<p  style=" color:darkslategray ; font-size:large"> We offer You So many type of Services You cane choose and contect us </p>
           
            <ul class="card-ul" style="display :flex;">

                <li>
                    <div class="card">
                        <img src="img\download.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Wedding ceramony</b></h3>
                            <p style="font-family: cursive;"> Indian Royal classic
                                <br /> Wedding
                            </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book</a></button>
                        </div>
                </li>



                <li>
                    <div class="card">
                        <img src="img\download (1).jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Corporet Events</b></h3>
                            <p style="font-family: cursive;">professional Bussines <br /> event</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\sosial.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Social Events</b></h3>
                            <p style="font-family: cursive;"> Social Event political <br />meeting</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book </a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\ngo.jpeg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Ngo Event</b></h3>
                            <p style="font-family: cursive;">Organise Event For<br /> Ngo programs </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>


            </ul>
            <ul class="card-ul" style="display :flex;">

                <li>
                    <div class="card">
                        <img src="img/fast.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Festival Function </b></h3>
                            <p style="font-family: cursive;"> Indian traditional Festival 
                                <br /> Functions
                            </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book</a></button>
                        </div>
                </li>



                <li>
                    <div class="card">
                        <img src="img\var.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Varchual event</b></h3>
                            <p style="font-family: cursive;">Onlie and varchual <br />  events <br /> </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\party.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Private events</b></h3>
                            <p style="font-family: cursive;"> Party and Meetup and <br />many more meeting</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book </a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\clg.jpg" alt="Avatar" style="width:230px ; height: 250px;">


                        <div class="container">
                            <h3><b>Collage Events</b></h3>
                            <p style="font-family: cursive;">Collage Farvel partys <br/>and  function</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>


            </ul>
        </div>
        </div>
    </section>
<hr/>
    <!--extra-->
    <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070 Sub servises</h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\pho.jpg" alt="Avatar" style="width:230px ; height: 250px;">
        <div class="container">
            <h3><b> Photography</b></h3>
            
            <br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\cat.jpg" alt="Avatar" style="width:230px ; height: 250px;">
        <div class="container">
            <h3><b>Catring  and Food </b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\dj.jpg" alt="Avatar" style="width:230px ; height: 250px;">

        <div class="container">

            <h3><b>Dj And Sound System</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\flowe.jpg" alt="Avatar" style="width:230px ; height: 250px;">

        <div class="container">
            <h3><b>Flower dacoration</b></h3>
            <br/>
            <br/>

      
        </div>
</li>


</ul>
</div>



    </section>
<hr/>
    <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070 Extra servises</h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\GAZl.jpg" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b> Entertenment</b></h3>
            
            <br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\car.jpg" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Car Rentel</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\macup.jpg" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">

            <h3><b>Macup Bridel</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img/invite.jpg" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">
            <h3><b>Invitaion card</b></h3>
            <br/>
            <br/>

      
        </div>
</li>


</ul>
</div>



    </section>

<hr/>

    <section class="section">
        <div class="para">
            <p class="sectag textbig ">Coutomisable</p>
            <p class="secsubtag textsm" >We Provides you customisable events for you ,
            You can choos extra services and sub services acording your need and made your event grat full. 
                </p>
                <p class="secsubtag textsm" style="color: darkslategrey;">
 You show pakeg and priceing details click on pkage and pricing Item in manu 
            </p>
        </div>
    </section>
    
        
    <hr/>
    <!--contectpage-->
    <table style="border: 2px solid darkgreen;  ;width :100%">
    <td>
    <section class="contect">
        <form action="contsubmit.php" method="POST">

            <h2 class="t-cont">ContectUs</h2>
            <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm"></h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\wattsep.png" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Conntect No </b></h3>
           <p style="color:darkslateblue;"> 9100000000
            <br/>
            7188181881
</p>
<br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\emai.png" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Email Address   </b></h3>
            <P style="color:darkslateblue;">
                eventkaro2005@gmail.com
                <br/>
                ek2005event@gmail.com
            </P>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\add.png" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">

            <h3><b>Address</b></h3>
            <p style="color:darkslateblue;">
            EventKaro<br>
            Jetpur Junaght rod  street 
            <br>no 9 near patrolpump<br>
            
</p>
        
            <br/>
            <br/>
        </div>
</li>
<li>
    


</ul>
</div>



    </section>
    
            <div class="form1">
                <input type="text" name="name" placeholder="Enter your name " required>
                <input type="text" name="mo" placeholder="Enter your mobileno " required pattern="[6789][0-9]{9}" title="Please enter valid phone number">
                <input type="email" name="em" placeholder="Enter your email " required>
                <input type="text" name="event" placeholder="Enter hear type of event " required>
                <input typt="text" name="ci" placeholder="Enter event Place">
                <input type="date" name="date" placeholder="Enter Eevet date" required>
                <textarea name="msg" cols="20" rows="10" placeholder="Enter yor message"></textarea>
                <div style="text-align: center; ">
                    <button class="" type="submit" name="submit" style="background-color: darkgreen; width: 80%;color: white; height: 30px; border: 1px solid ; border-radius: 9px; margin-top: 20px;">Submit</button>
                </div>
            </div>
        </form>

    </section>
</td>    
</table>
        <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>


        <!--<center>  <video class="vid" style="align-items: center;"  width="500" height="400" controls>
        <source src="C:\Users\DELL\Downloads\Untitled video (1).mp4" type="video/mp4">
        
      Your browser does not support the video tag.
      </video></center>
      <p class="vidtext">davayat khavad video</p>-->
        <script src="resp.js"></script>




</body>

</html>