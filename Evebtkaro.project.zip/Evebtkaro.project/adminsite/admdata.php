<?php
$servername = "localhost";
$username = "root";
$password = "";
$database= "eventkaro";

$mysqli =new MySQLi ($servername , $username, $password,$database);
// Check connection

$sql = " SELECT * FROM sinup  ";
$result = $mysqli->query($sql);
$mysqli->close();


?>
<!-- HTML code to display data in tabular format -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Register user info </title>
    <link rel="icon" href="..\img\admin.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

<!DOCTYPE html>
<html lang="en">

    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
 
        h1 {
            text-align: center;
            color: darkslategrey;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
 
        td {
            font-weight: lighter;
        }
    </style>
</head>
<body>
<div class="nevbar background h-nev-resp ">
    
    <ul class="nevlist  v-class-resp">
        <div class="logo"><img src="..\img\loek.png" alt="logo">
        <a style="text-decoration: none;"  href="admin.php"><h1 style=" margin: 15px 0px 10px 0px; color:lightgoldenrodyellow; font-family:Georgia, 'Times New Roman', Times, serif; font-size: large;">EventKaro-Admin </h1><a>
        </div>
          
        
        <li class="admin"><a href="admdata.php">Register user   </a></li>
        <li class="admin"><a href="conadata.php">Booking inquire  </a></li>

        <ul >
                <li class="padlog" > <button   class="logbtn "><a style="color: cadetblue;" href="admout.php">Logout</a></button></li></ul>
        </ul>  
    

   <div class="burger">
    <div class="burger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    </div>
</div>
</nev>

    <section style="padding-top: 50px; padding-bottom: 300px;">
        <h1>Register User Info</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>Id</th>
                <th> First name</th>
                <th>Lastname</th>
                <th>Mobie no</th>
                <th>Email </th>
                <th>City </th>
                <th>User_name </th>
                <th>Password </th>



            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS -->
            <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $rows['id'];?></td>
                <td><?php echo $rows['fname'];?></td>
                <td><?php echo $rows['lname'];?></td>
                <td><?php echo $rows['mobileno'];?></td>
                <td><?php echo $rows['email'];?></td>
                <td><?php echo $rows['city'];?></td>
                <td><?php echo $rows['uname'];?></td>
                <td><?php echo $rows['password'];?></td>

            </tr>
            <?php
                }
            ?>
        </table>
    </section>
    <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="../resp.js"></script>
</body>
 
</html>

<!-- HTML code to display data in tabular format -->

?>