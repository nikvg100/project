<?php 
session_start ();
if(!isset($_SESSION["login"]))
	header("location:logadmin.php");


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> EventKaro -Admin</title>
    <link rel="icon" href="..\img\admin.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
<div class="nevbar background h-nev-resp ">
    
    <ul class="nevlist  v-class-resp">
        <div class="logo"><img src="..\img\loek.png" alt="logo">
            <h1 ><a style="text-decoration: none;"  href="admin.php"><h1 style=" margin: 15px 0px 10px 0px; color:lightgoldenrodyellow; font-family:Georgia, 'Times New Roman', Times, serif; font-size: large;">EventKaro-Admin </h1><a>
        </div>
          
        
        <li class="admin"><a href="admdata.php">Register user   </a></li>
        <li class="admin"><a href="conadata.php">Booking inquire  </a></li>

        <ul >
                <li class="padlog" > <button   class="logbtn "><a style="color: cadetblue;" href="admout.php">Logout</a></button></li></ul>
        </ul>  
    

   <div class="burger">
    <div class="burger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    </div>
</div>
</nev>
<h1 style="text-align: center; color: darkslateblue; padding-top: 30px; padding-bottom: 20px;"> welocme in EvenKaro.com Admin panel</h1>
<h2 style="text-align: center; color: darkolivegreen; padding-bottom: 450px;">You can see the information of Registr user and Booking Inquiry in this panel   </h2>
<!--<button style=" background-color: darkslateblue; height: 30px; width: 300px; text-align: center;"><a style="text-decoration: none; color:white" href="../admout.php">logout</a></button>
-->     <script src="../resp.js"></script>
        
<footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
</body>
</html>