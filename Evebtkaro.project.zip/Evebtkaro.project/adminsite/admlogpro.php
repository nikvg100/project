<?php
// Connect to your database here (make sure to replace the placeholders with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$database= "eventkaro";

$con =new MySQLi ($servername , $username, $password,$database);
// Check connection
if ($con->connect_error) {
   printf("Connection failed: " ,$mysqli->connect_error);
    exit();
    }
    printf("connection sucses fully");
session_start();
    $username = $_POST['uname'];  
    $password = $_POST['password'];  
      
    $username = stripcslashes($username);  
            $password = stripcslashes($password);  
            $username = mysqli_real_escape_string($con, $username);  
            $password = mysqli_real_escape_string($con, $password);  
          
    
        $sql = "select *from admin where uname = '$username' and password = '$password'";  
        $res = mysqli_query($con, $sql);  
       $row = mysqli_fetch_array($res, MYSQLI_ASSOC);  
     $count = mysqli_num_rows($res);  
          
        if($count===1){  
            $_SESSION["login"]="2";
            echo "<script>window.location.href='./admin.php';
            alert('Welcom You are succes fully login');</script>";
          
               }  
        else{  
            echo "<script>window.location.href='logadmin.php';
            alert(' Login failed. Invalid username or pass');</script>";
           // header("location:login.php");
        }
     
