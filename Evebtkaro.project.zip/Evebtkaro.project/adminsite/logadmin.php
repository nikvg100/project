<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Admin Login</title>
    <link rel="icon" href="/img/admin.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
    <header> <h1 style="text-align: center; color:darkslateblue;">Welcome in Admin Login</h1></header>
<section class="contect">
        
        <form action="admlogpro.php" method="POST">
            
            <br/><br/>
            <h2 class="t-cont">Login</h2>
            <div class="form1">
           
               
              <input type="text" name="uname" placeholder="Enter your username" required>
                <input type="password" name="password" placeholder="Enter Your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" >
                  
                <div style="text-align: center; ">
                    <button class="" type="submit" name="login" style="background-color: darkslategray; width: 80%;color: white; height: 30px; border: 1px solid ; border-radius: 9px; margin-top: 20px;">Login</button>
                </div>
              <br/>
              <br/>
              <br/>
              <br/>
              <br/>
              <br/>
            <br/>
              <br/>
              <br/>
              <br/>
              <br/>
              <br/>

            </div>
        </form>
    </section>
    <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="../resp.js"></script>

</body>

</html>