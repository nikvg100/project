<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> EventKaro</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>
<body>
<div class="nevbar background h-nev-resp ">
    
    <ul class="nevlist  v-class-resp">
        <div class="logo"><img src="img\loek.png" alt="logo">
            <h1 style=" margin: 12px 0px 10px 0px; color:mintcream; font-family:Georgia, 'Times New Roman', Times, serif;">EventKaro</h1>
        </div>
          
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">AboutUs</a></li>

        <li class="nik"><a href="serv.php">Servises</a>
            
        </li>


        <li><a href="price.php">Pcakage-price</a></li>

        <li class="contectus"><a href="contect.php">Contectus<button class="btn-book" type="submit">BookUs</button>
            </a></li>
          
            <ul >
                <li class="padlog" > <button   class="logbtn "><a style="color: cadetblue;" href="login.php">Login</a></button></li></ul>
        </ul>
    

   <div class="burger">
    <div class="burger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    </div>
</div>
</nev>

</body>
</html>