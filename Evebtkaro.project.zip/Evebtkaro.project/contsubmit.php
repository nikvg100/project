

<?php
// Connect to your database here (make sure to replace the placeholders with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$database= "eventkaro";

$mysqli =new MySQLi ($servername , $username, $password,$database);

// Check connection
//if ($mysqli->connect_error) {
  //  printf("Connection failed: " ,$mysqli->connect_error);
    //exit();

//}
//printf("connection sucses fully");

$name =$_POST['name'];
$mobileno=$_POST['mo'];
$email=$_POST['em'];
$event= $_POST['event'];
$city=$_POST['ci'];
$date=$_POST['date'];
$msg =$_POST['msg'];

// Insert data into the database
$sql = "INSERT INTO `contect`(`id`, `name`, `mobileno`, `email`, `event`, `city`, `date`, `msg`) VALUES ('','$name',
'$mobileno','$email','$event','$city','$date','$msg')";

/*if ($mysqli->query($sql) === TRUE) {
    echo "your request submited successful!";
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}
*/
//echo "$sql";



$result= mysqli_query($mysqli,$sql);


if($result)
{
    echo "<script>window.location.href='index.php';
    alert('your request is submited succesfulluy our team is contect you as soon as');</script>";

}
else{
    echo 'data not inserted';
}

?>
