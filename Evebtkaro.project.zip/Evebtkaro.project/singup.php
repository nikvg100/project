<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Sing up</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>

<!--singup-->

    <section class="contect">
        
        <form action="reg.php" method="POST">
            <h2 class="t-cont">Register Your Details</h2>
            <div class="form1">
           <a  href="index.php"><p style=" text-align:end ;;margin-block-end: 70px;">&#10006<p></a>
                <input type="text" name="fname" placeholder="Enter your FirstName " required>
                <input type="text" name="lname" placeholder="Enter your LastName " required>
                <input type="tex" name="mo" placeholder="Enter your Mobile Number " pattern="[6789][0-9]{9}" title="Please enter valid phone number">
                <input type="email" name="em" placeholder="Enter your email " required>
                <input typt="city" name="ci" placeholder="Enter Your city" required>
                <input typt="text" name="username" placeholder="Enter Your Username" required>
              
                <input type="password" name="password" placeholder="Enter Your password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" >
                  
                <div style="text-align: center; ">
                    <button class="" type="submit" name="submit" style="background-color: darkgreen; width: 80%;color: white; height: 30px; border: 1px solid ; border-radius: 9px; margin-top: 20px;">Singup</button>
                </div>
              
                

            </div>
        </form>
    </section>
    <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="resp.js"></script>

</body>

</html>