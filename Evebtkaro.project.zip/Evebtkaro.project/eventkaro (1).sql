-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 15, 2023 at 09:26 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventkaro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uname` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `password`) VALUES
(15, 'nik', '12Nikhil');

-- --------------------------------------------------------

--
-- Table structure for table `contect`
--

DROP TABLE IF EXISTS `contect`;
CREATE TABLE IF NOT EXISTS `contect` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `mobileno` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `event` varchar(30) NOT NULL,
  `city` varchar(200) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `msg` varchar(280) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contect`
--

INSERT INTO `contect` (`id`, `name`, `mobileno`, `email`, `event`, `city`, `date`, `msg`) VALUES
(28, 'nikhil', '9510042171', 'nikhil@gmail.kom', 'wedding', 'jetpur', '2023-09-29', 'grand wedding');

-- --------------------------------------------------------

--
-- Table structure for table `sinup`
--

DROP TABLE IF EXISTS `sinup`;
CREATE TABLE IF NOT EXISTS `sinup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sinup`
--

INSERT INTO `sinup` (`id`, `fname`, `lname`, `mobileno`, `email`, `city`, `uname`, `password`) VALUES
(7, 'krushil', 'patel', '9090909090', 'krushil12@gmail.com', 'jetpur', 'kru', '12Krushi'),
(6, 'nikhil', 'patel', '9510042171', 'nikhil@gmial.com', 'jetpur', 'nik', '12Nikhil');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
