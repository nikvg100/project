<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Contect-us</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>

    <?php include 'nev.php' ?>
    <table style="border: 2px solid darkgreen;  width :100%">
    <td>
    <section class="contect">

        <form action="contsubmit.php" method="POST">
            <h2 class="t-cont">ContectUs</h2>
            <!--extra-->
    <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm"></h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\wattsep.png" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Conntect No </b></h3>
           <p style="color:darkslateblue;"> 9100000000
            <br/>
            7188181881
</p>
<br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\emai.png" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Email Address   </b></h3>
            <P style="color:darkslateblue;">
                eventkaro2005@gmail.com
                <br/>
                ek2005event@gmail.com
            </P>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\add.png" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">

            <h3><b>Address</b></h3>
            <p style="color:darkslateblue;">
            EventKaro<br>
            Jetpur Junaght rod  street 
            <br>no 9 near patrolpump<br>
            
</p>
        
            <br/>
            <br/>
        </div>
</li>
<li>
    


</ul>
</div>



    </section>
            <a  href="index.php"><p style="padding-left: 1200px; margin-block-end: 70px;">&#10006<p></a>

            <div class="form1">
                <input type="text" name="name" placeholder="Enter your name " required>
                <input type="text" name="mo" placeholder="Enter your mobileno "  pattern="[6789][0-9]{9}" title="Please enter valid phone number">
                <input type="email" name="em" placeholder="Enter your email " required>
                <input type="text" name="event" placeholder="Enter hear type of event " required>
                <input typt="text" name="ci" placeholder="Enter event Place">
                <input type="date" name="date" placeholder="Enter Eevet date" required>
                <textarea name="msg" cols="20" rows="10" placeholder="Enter yor message"></textarea>
                <div style="text-align: center; ">
                    <button class="" type="submit" name="submit" style="background-color: darkgreen; width: 80%;color: white; height: 30px; border: 1px solid ; border-radius: 9px; margin-top: 20px;">Submit</button>
                </div>
            </div>
        </form>
    </section>
    </td>
    </table>



    <footer>
        <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
    </footer>
    <script src="resp.js"></script>

</body>

</html>