<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> About-us</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
<?php include 'nev.php' ?>

<section class="section ">
        <div class="para ">
        <!--<div class="thumbnel">
                <img src="img\loek.png" alt="Aboutnus" class="imgFluid">
</div>-->
        <p class="sectag textbig" style="padding-top: 50px;">About-Us</p>
       <br/>
            <br/>
            <br/>
            <br/>

            <p class=" secsubtag textsm" >
            
<table style="border: 2px solid darkgreen;  ;width :98%">
           <h2 style="color:darkslategrey">Company Name: EventKaro</h2>
    <br/>
        <h2>Established Since: 2005</h2>
        <br/>
        <h2>Mission:</h2>
        <p style="font-size: medium ;color:darkslategrey">EventKaro is dedicated to creating memorable and seamless event experiences that leave a lasting impression. We believe in the power of exceptional event management to bring people together, inspire, and celebrate life's special moments.</p>
        <br/>
        <h2>Our Story:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">Founded in 2005, EventKaro has been a pioneer in the event management industry, delivering outstanding services and unparalleled creativity for nearly two decades. Our journey began with a passion for turning ordinary events into extraordinary experiences. Over the years, we have grown and evolved, always staying at the forefront of industry trends and technologies.</p>
        <br/>
        <h2>What We Do:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">EventKaro specializes in comprehensive event management services tailored to the unique needs and visions of our clients. We offer a wide range of services, including:</p>
        <br/>
        <ol>
            <li >Corporate Events: From conferences and seminars to product launches and team-building activities, we help businesses create impactful events that drive success and engagement.</li>
            <li>Social Events: We excel in planning and executing social gatherings such as weddings, birthdays, anniversaries, and more, ensuring that each moment is cherished.</li>
            <li>Concerts and Entertainment: Our expertise extends to organizing concerts, live performances, and entertainment events that leave audiences thrilled.</li>
            <li>Exhibitions and Trade Shows: We help businesses showcase their products and services effectively through meticulously organized exhibitions and trade shows.</li>
            <li>Destination Management: EventKaro handles all aspects of destination events, ensuring seamless planning, logistics, and execution in the most picturesque locations.</li>
        </ol>
        <br/>
        <h2>Why Choose EventKaro:</h2>
        <br/>
        <ul>
            <li>Experience: With almost two decades of experience, EventKaro has a proven track record of delivering exceptional events.</li>
            <li>Creativity: Our team of talented professionals brings innovative and creative ideas to every project, ensuring a unique and memorable experience.</li>
            <li>Attention to Detail: We are known for our meticulous planning and execution, leaving no stone unturned to make your event flawless.</li>
            <li>Client-Centric Approach: We prioritize our clients' needs and preferences, working closely with them to bring their vision to life.</li>
            <li>Cutting-Edge Technology: We leverage the latest event management tools and technologies to enhance the event experience.</li>
        </ul>
        <br/>
        <h2>Contact Us:</h2>
        <br/>
        <p style="font-size: medium ;color:darkslategrey">For inquiries and consultations, please reach out to us at:</p>
        <br/>
        <address>
            EventKaro<br>
            [Jetpur Junaght rod  street no 9 near patrolpump]<br>
            [951000000]<br>
            [eventkaro2005@gmail.com]<br>
            
        </address>
        
        <p style="font-size: medium ;color:darkslategrey">At EventKaro, we believe that every event is an opportunity to create magic. Let us be your partner in crafting unforgettable moments that will be cherished for a lifetime.</p>
</table>


        
    </section>
    <footer>

            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="resp.js"></script>

</body>
</html>