<?php
// Connect to your database here (make sure to replace the placeholders with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$database= "eventkaro";

$mysqli =new MySQLi ($servername , $username, $password,$database);
$fname =$_POST['fname'];
$lname =$_POST['lname'];
$mobileno=$_POST['mo'];
$email=$_POST['em'];
$city=$_POST['ci'];
$username=$_POST['username'];
$password =$_POST['password'];

$sql ="INSERT INTO `sinup`(`id`, `fname`, `lname`, `mobileno`, `email`, `city`, `uname`, `password`) VALUES ('','$fname','$lname','$mobileno','$email','$city','$username','$password')";
$result= mysqli_query($mysqli,$sql);


if($result)
{
    echo "<script>window.location.href='login.php';
    alert(' YOUR DETAILS IS SUBMITED SUCCSES FULLY');</script>";

}
else{
    echo 'data not inserted';
}
