<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> services</title>
    <link rel="icon" href="img\2logo.png">
    <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>

<body>
<?php include 'nev.php' ?>

<section class="section s-left">
        <div class="para">
            <p  class="sectag textbig ">services</p>
            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070Type Of Event</h2>
<p  style=" color:darkslategray ; font-size:large"> We offer You So many type of Services You cane choose and contect us </p>
           
            <ul class="card-ul" style="display :flex;">

                <li>
                    <div class="card">
                        <img src="img\download.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Wedding ceramony</b></h3>
                            <p style="font-family: cursive;"> Indian Royal classic
                                <br /> Wedding
                            </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book</a></button>
                        </div>
                </li>



                <li>
                    <div class="card">
                        <img src="img\download (1).jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Corporet Events</b></h3>
                            <p style="font-family: cursive;">professional Bussines <br /> event</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\sosial.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Social Events</b></h3>
                            <p style="font-family: cursive;"> Social Event political <br />meeting</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book </a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\ngo.jpeg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Ngo Event</b></h3>
                            <p style="font-family: cursive;">Organise Event For<br /> Ngo programs </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>


            </ul>
            <ul class="card-ul" style="display :flex;">

                <li>
                    <div class="card">
                        <img src="img/fast.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Festival Function </b></h3>
                            <p style="font-family: cursive;"> Indian traditional Festival 
                                <br /> Functions
                            </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book</a></button>
                        </div>
                </li>



                <li>
                    <div class="card">
                        <img src="img\var.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Varchual event</b></h3>
                            <p style="font-family: cursive;">Onlie and varchual <br />  events <br /> </p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\party.jpg" alt="Avatar" style="width:230px ; height: 250px;">
                        <div class="container">
                            <h3><b>Private events</b></h3>
                            <p style="font-family: cursive;"> Party and Meetup and <br />many more meeting</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php">Contect For Book </a></button>
                        </div>
                </li>
                <li>
                    <div class="card">
                        <img src="img\clg.jpg" alt="Avatar" style="width:230px ; height: 250px;">


                        <div class="container">
                            <h3><b>Collage Events</b></h3>
                            <p style="font-family: cursive;">Collage Farvel partys <br/>and  function</p>
                            <button style="align-items: center;  background-color:darkslategrey; " class="btn "><a style=" text-decoration:none; color: white;" href="contect.php"> Contect For Book</a></button>
                        </div>
                </li>


            </ul>
        </div>
        </div>
    </section>
<hr/>
    <!--extra-->
    <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070 Sub servises</h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\pho.jpg" alt="Avatar" style="width:230px ; height: 250px;">
        <div class="container">
            <h3><b> Photography</b></h3>
            
            <br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\cat.jpg" alt="Avatar" style="width:230px ; height: 250px;">
        <div class="container">
            <h3><b>Catring  and Food </b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\dj.jpg" alt="Avatar" style="width:230px ; height: 250px;">

        <div class="container">

            <h3><b>Dj And Sound System</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\flowe.jpg" alt="Avatar" style="width:230px ; height: 250px;">

        <div class="container">
            <h3><b>Flower dacoration</b></h3>
            <br/>
            <br/>

      
        </div>
</li>


</ul>
</div>



    </section>
<hr/>
    <section class="section s-left">
        <div class="para">

            <h2 style="color:darkslateblue ; font-family: 'Times New Roman', Times, serif; background-color: whitesmoke; " class="secsubtag textsm">&#10070 Extra servises</h2>
            <ul class="card-ul" style="display :flex;">

<li>
    <div class="card">
        <img src="img\GAZl.jpg" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b> Entertenment</b></h3>
            
            <br/>
            <br/>
        </div>
</li>



<li>
    <div class="card">
        <img src="img\car.jpg" alt="Avatar" style="width:200px ; height: 200px;">
        <div class="container">
            <h3><b>Car Rentel</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img\macup.jpg" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">

            <h3><b>Macup Bridel</b></h3>
            <br/>
            <br/>
        </div>
</li>
<li>
    <div class="card">
    <img src="img/invite.jpg" alt="Avatar" style="width:200px ; height: 200px;">

        <div class="container">
            <h3><b>Invitaion card</b></h3>
            <br/>
            <br/>

      
        </div>
</li>


</ul>
</div>



    </section>


    <footer>
            <p class="text-footer"> Copyright &COPY;2027 -All right reserved EventKaro.com</p>
        </footer>
        <script src="resp.js"></script>

</body>
</html>